# -*- coding: utf-8 -*-
"""Fixtures for the SWIM-AI test-suite."""
from __future__ import annotations

import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
